# CRM Mobile — Marouan

Ce dossier est prêt pour GitHub Pages.

## Installation rapide

1. Créer un nouveau dépôt GitHub.
2. Envoyer le fichier `index.html` dans le dépôt.
3. Aller dans Settings > Pages.
4. Dans "Build and deployment", choisir :
   - Source : Deploy from a branch
   - Branch : main
   - Folder : /root
5. Ouvrir le lien GitHub Pages généré.
6. Sur téléphone Android : ouvrir le lien dans Chrome > menu ⋮ > Ajouter à l'écran d'accueil / Installer l'application.
